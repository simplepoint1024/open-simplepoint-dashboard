declare const _default: {
    'platform.dna-drivers': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-data-sources': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-metadata': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-dialects': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-federation-jdbc-users': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-federation-query-policies': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-federation-query-audits': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
    'platform.dna-federation-sql-console': {
        baseUrl: string;
        i18nNamespaces: string[];
        name: string;
    };
};
export default _default;
